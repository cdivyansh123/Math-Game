package com.company.mathgame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;


public class Game extends AppCompatActivity {

    TextView score;
    TextView life;
    TextView time;

    TextView question;
    EditText answer;

    Button ok;
    Button next;
    Random random=new Random();

    int number1;
    int number2;
    int userans;
    int realans;
    int userscore=0;
    int userlife=3;

    CountDownTimer timer;
    private static final long START_TMER_INMILIS=60000;
    boolean timer_running;
    long left_time_in_milis=START_TMER_INMILIS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        score=findViewById(R.id.score);
        life=findViewById(R.id.life);
        time=findViewById(R.id.time);
        question=findViewById(R.id.ques);
        answer=findViewById(R.id.ans);
        ok=findViewById(R.id.ok);
        next=findViewById(R.id.next);

        gameContinue();

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userans=Integer.valueOf(answer.getText().toString());
                pauseTimer();
                if(userans==realans){
                    userscore=userscore+10;
                    score.setText(""+userscore);
                    question.setText("Congratulations, Your answer is True....! ");
                }else{
                    userlife--;
                    life.setText(""+userlife);
                    question.setText("!!...Try Again...Your answer is Incorrect...!!");
                }
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resettimer();
                answer.setText("");


                if(userlife<=0){
                    Toast.makeText(getApplicationContext(), "Game Over", Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(Game.this,result.class);
                    intent.putExtra("score",userscore);
                    startActivity(intent);
                    finish();
                }else{
                    gameContinue();
                }

            }
        });
    }

    public void gameContinue(){
        number1=random.nextInt(500);
        number2=random.nextInt(800);
        realans=number1+number2;

        question.setText(number1 + " + " + number2);
        starttimer();
    }
    public void starttimer(){
        timer=new CountDownTimer(left_time_in_milis,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                left_time_in_milis=millisUntilFinished;
                updatetext();
            }

            @Override
            public void onFinish() {
                timer_running=false;
                pauseTimer();
                resettimer();
                updatetext();
                userlife=userlife-1;
                life.setText(""+userlife);
                question.setText("!...Sorry...Time Up..!");
            }
        }.start();
        timer_running=true;
    }
    public void updatetext(){
        int second=(int)(left_time_in_milis/1000)%60;
        String time_lest=String.format(Locale.getDefault(),"%02d",second);
        time.setText(time_lest);
    }
    public void pauseTimer(){
        timer.cancel();
        timer_running=false;
    }
    public void resettimer(){
        left_time_in_milis=START_TMER_INMILIS;
        updatetext();
    }

}